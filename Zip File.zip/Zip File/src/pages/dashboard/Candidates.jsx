const Candidates = () => <h2 className="text-xl font-bold">Candidate List Page</h2>;
export default Candidates;
