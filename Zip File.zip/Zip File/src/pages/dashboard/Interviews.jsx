const Interviews = () => {
  return <h2 className="text-xl font-bold">Interviews Page</h2>;
};

export default Interviews;
