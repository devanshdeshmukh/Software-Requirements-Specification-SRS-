const Reports = () => {
  return <h2 className="text-xl font-bold">Reports Page</h2>;
};

export default Reports;
