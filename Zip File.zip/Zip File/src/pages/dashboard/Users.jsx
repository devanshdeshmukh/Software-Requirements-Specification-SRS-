const Users = () => {
  return <h2 className="text-xl font-bold">Users Page</h2>;
};

export default Users;
