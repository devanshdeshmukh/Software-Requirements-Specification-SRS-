const Settings = () => {
  return <h2 className="text-xl font-bold">Settings Page</h2>;
};

export default Settings;
