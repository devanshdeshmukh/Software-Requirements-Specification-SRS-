const Jobs = () => <h2 className="text-xl font-bold">Job Management Page</h2>;
export default Jobs;
