const DashboardHome = () => <h2 className="text-xl font-bold">Welcome to the Dashboard</h2>;
export default DashboardHome;
