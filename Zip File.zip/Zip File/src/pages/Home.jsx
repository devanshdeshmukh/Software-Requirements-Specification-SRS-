// src/pages/Home.jsx
const Home = () => {
  return (
    <div className="text-center mt-10">
      <h1 className="text-3xl font-bold">Welcome to the Home Page</h1>
      <p>You are logged in.</p>
    </div>
  );
};

export default Home;

// import React from 'react'

// function Home() {
//   return (
//     <div>Home</div>
//   )
// }

// export default Home
